import {
  require_react
} from "./chunk-OBOR3357.js";
export default require_react();
